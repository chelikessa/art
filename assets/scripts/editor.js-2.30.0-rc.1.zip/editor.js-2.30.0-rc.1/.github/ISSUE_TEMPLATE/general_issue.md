---
name: General Issue
about: Well-designed, algorithmized feature/idea/improvement issue for Editor.js
title: ''
labels: ''
assignees: ''

---

The question.

Why and how the question has come up.

<!--
🤫 If you like Editor.js, please consider supporting us via OpenCollective:
https://opencollective.com/editorjs
-->
