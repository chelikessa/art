/**
 * Debounce timeout for selection change event
 * {@link modules/ui.ts}
 */
export const selectionChangeDebounceTimeout = 180;
