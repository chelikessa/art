/**
 * Unique identifier of a block
 */
export type BlockId = string;
